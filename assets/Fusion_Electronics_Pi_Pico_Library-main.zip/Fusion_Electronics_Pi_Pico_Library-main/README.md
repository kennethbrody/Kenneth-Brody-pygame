# Fusion_Electronics_Pi_Pico_Library
A Fusion Electronics Library containing the Raspberry Pi Pico

Download the files, upload them to a folder in Autodesk Fusion, and they should be there with 3D models attached and all.
